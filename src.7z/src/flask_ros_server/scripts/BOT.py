#!/usr/bin/env python
import rospy
from flask_ros_server.srv import *

 
def BOT_pipline_handler(req):
  print "inside BOT pipeline"
  print "X-coord", req.dest_x, "Y-coord", req.dest_y
 

  response = XY_destResponse()
  response.status = "Processed by BOT"
  return response
  

if __name__ == '__main__':
  rospy.init_node('Bot_node')

  sGCBAC = rospy.Service('coordinate_service', XY_dest, BOT_pipline_handler)
            
  print "BOT is ready"

  # rate =rospy.Rate(2)
  # while not rospy.is_shutdown():
    # rate.sleep()
  
  rospy.spin()