#!/usr/bin/env python
import rospy
from std_msgs.msg import PoseStamped, String, Int16MultiArray
from nav_msgs.msg import Path
from geometry_msgs.msg import Pose

def path_callback(msg):
  1=1

def current_position_callback(msg):
  1=1



if __name__ == '__main__':
  rospy.init_node('controller_node')

  path_topic_handle = rospy.Subscriber("/botpath",Int16MultiArray, path_callback )
  rospy.Subscriber("/current_pose", PoseStamped, current_position_callback)  