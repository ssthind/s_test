#!/usr/bin/env python
import random
import json


from flask import Flask, jsonify, make_response
from flask import request
from random import randint

import rospy
from flask_ros_server.srv import *

app = Flask(__name__)


#  Entry level method for Sally analyzer.
#  It accpets aisle image path and product image path
#  as input and calls model pipeline to process
@app.route('/Sally/xy', methods = ['POST'])
def send_coordinate():
  print('request.args ', request.form)
  
  # xy_array=request.form.get('xy_coord', type=str)
  xy_array = XY_destRequest()
  xy_array.dest_x=request.form.get('x_coord', type=float)
  xy_array.dest_y=request.form.get('y_coord', type=float)
  response_text = send_ros(xy_array)
  resp = make_response(json.dumps(response_text))
  resp.headers['Access-Control-Allow-Origin'] = '*'
  return resp

   
def send_ros(msg):
  # global service_call
  rospy.wait_for_service('coordinate_service')
  
  service_call = rospy.ServiceProxy('/coordinate_service', XY_dest)
  
  while True:
    try:
      resp1 = service_call(msg)
      print( resp1.status )
      return resp1
    except rospy.ServiceException, ex:
      time.sleep(1)
      continue


if __name__ == '__main__':

  rospy.init_node('App')
  # app.run(host='127.0.0.1')
  # app.run(host='0.0.0.0', port=5000)
  app.run(host='172.20.5.101', port=5000)



  