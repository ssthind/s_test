#!/usr/bin/env python
import rospy
import numpy as np
from flask_ros_server.srv import *
#from std_msgs.msg import PoseStamped, String, Int16MultiArray
from std_msgs.msg import String
from nav_msgs.msg import Path
from geometry_msgs.msg import Pose
# from flask_ros_server.msg import 2darray
from visualization_msgs.msg import Marker

import collections
import ctypes
import os

wall, clear, goal = "0", "1", "2"
print "pwd:", os.getcwd()
mat = np.loadtxt('/mnt/d/PowerProgrammers/Hackthons/STG/us/Sally_ws/src/flask_ros_server/scripts/mat.txt', dtype=str)

#code to find path
height = len(mat)
width = len(mat[0])

def bfs(grid, start):
  queue = collections.deque([[start]])
  seen = set([start])
  while queue:
    path = queue.popleft()
    x, y = path[-1]
    if grid[y][x] == goal:
      print "Path:", type(path)
      return path
    for x2, y2 in ((x+1,y), (x-1,y), (x,y+1), (x,y-1)):
      if 0 <= x2 < width and 0 <= y2 < height and grid[y2][x2] != wall and (x2, y2) not in seen:
        queue.append(path + [(x2, y2)])
        seen.add((x2, y2))
 

 
def BOT_pipline_handler(req):
  global path_topic_handle, current_position
  print "inside BOT pipeline"
  print "X-coord", req.dest_x, "Y-coord", req.dest_y
  
  # Code to load matrix from file
  # np.savetxt('mat.txt', grid, fmt='%s')
  goal_x = int(req.dest_x)
  goal_y = int(req.dest_y)
  #goal pos = [1,2]
  print(mat[goal_y])
  row = list(mat[goal_y])
  row[goal_x] = goal
  mat[goal_y] = "".join(row)
  for i in mat:
    print(i)
  print(height, width)

  #call bfs with current position
  # path =  bfs(mat, (current_position.pose.position.x, current_position.pose.position.y))
  path =  bfs(mat, (1,2))
  print(path)
#  path_multi = Int16MultiArray()
  # path_multi.layout = (height, width)
  # path_multi.data = path[-1]
  str_path= str(path)
  path_topic_handle.publish(str_path)

  response = XY_destResponse()
  response.status = "Processed by BOT"
  return response

  
def current_position_callback(msg):
  global current_position
  current_position = msg
  

if __name__ == '__main__':
  rospy.init_node('Bot_node')

  serv_hndl = rospy.Service('coordinate_service', XY_dest, BOT_pipline_handler)
  # path_topic_handle = rospy.Publisher("/botpath",Int16MultiArray, queue_size=1, latch=True )
  path_topic_handle = rospy.Publisher("/botpath",String, queue_size=1, latch=True )
  # path_topic_handle = rospy.Publisher("/botpath",2darray, queue_size=1, latch=True )
  rospy.Subscriber("/visualization_marker", Marker, current_position_callback)  
  
  
  print "BOT is ready"

  # rate =rospy.Rate(2)
  # while not rospy.is_shutdown():
    # rate.sleep()
  
  rospy.spin()